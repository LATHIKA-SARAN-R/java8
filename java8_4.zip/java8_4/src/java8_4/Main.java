package java8_4;

import java.util.*;
import java.util.stream.*;
  
public class Main {
    public static void main(String[] args) {
        List<User> users = new ArrayList<>();

        users.add(new User(1, "Amit", 50000.0));
        users.add(new User(2, "Priya", 60000.0));
        users.add(new User(3, "Rahul", 55000.0));
        users.add(new User(4, "Sneha", 70000.0));
        users.add(new User(5, "Vikram", 48000.0));
        users.add(new User(6, "Pooja", 62000.0));
        users.add(new User(7, "Rohit", 75000.0));
        users.add(new User(8, "Neha", 58000.0));
        users.add(new User(9, "Ankit", 54000.0));
        users.add(new User(10, "Kiran", 67000.0));

    
        System.out.println("Users with names starting with 'P':");
        users.stream()
             .filter(u -> u.getName().startsWith("P"))
             .forEach(u -> System.out.println(u.getName()));

      
        System.out.println("\nUsers with salary > 60000:");
        List<User> highSalaryUsers = users.stream()
                                          .filter(u -> u.getSalary() > 60000)
                                          .collect(Collectors.toList());
        highSalaryUsers.forEach(u -> System.out.println(u.toString()));

      
        System.out.println("\nUser names in uppercase:");
        users.stream()
             .map(u -> u.getName().toUpperCase())
             .forEach(System.out::println);

   
        System.out.println("\nMap of user IDs and names:");
        Map<Integer, String> userMap = users.stream()
                                            .collect(Collectors.toMap(u -> u.getId(), u -> u.getName()));
        
        System.out.println(  users.stream().max((u1,u2)-> Double.compare(u1.getSalary(),u2.getSalary())));
        
       
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter user name to get salary: ");
        String inputName = sc.nextLine();

        users.stream()
             .filter(u -> u.getName().equalsIgnoreCase(inputName))
             .findFirst()
             .ifPresentOrElse(
                 u -> System.out.println("Salary of " + inputName + ": " + u.getSalary()),
                 () -> System.out.println("User not found."));
    }
}