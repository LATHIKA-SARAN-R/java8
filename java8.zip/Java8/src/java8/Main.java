package java8;

public class Main {

    public static void main(String[] args) {

        int a = 20, b = 50;

        Calculator sum = (x, y) -> x + y;

        int result = sum.cal(a, b);

        System.out.println("Sum: " + result);
    }
}
