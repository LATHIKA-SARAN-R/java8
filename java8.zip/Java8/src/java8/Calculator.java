package java8;
 
 
@FunctionalInterface
 
public interface Calculator {
public int  cal(int a, int b);
 
	
	
 
}
