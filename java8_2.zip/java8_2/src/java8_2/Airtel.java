package java8_2;

public class Airtel implements Sim {
    @Override
    public void calling() {
        System.out.println("Calling using Airtel network");
    }
}
