package java8_2;

public class Vodaphone implements Sim {
    @Override
    public void calling() {
        System.out.println("Calling using Vodafone network");
    }
}
