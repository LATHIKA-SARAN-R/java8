package java8_2;

@FunctionalInterface
public interface Sim {
    void calling();
    default void message() {
        System.out.println("Sending message...");
    }
}
