package java8_2;

public class Main {
    public static void main(String a[]) {
        Airtel obj1 = new Airtel();
        obj1.calling();
        obj1.message();
    }
}
