package java8;

@FunctionalInterface
public interface Payment {
    double cashBill(double amt); 

    default double diwaliDiscount(double amt) {
        return amt - (amt * 5 / 100);
    }
}
