package java8;

public class Main {
    public static void main(String[] args) {

        double amount = 1000;

        Payment upi = (amt) -> amt - (amt * 5 / 100);           
        Payment cash = (amt) -> amt - (amt * 10 / 100);         
        Payment creditCard = (amt) -> amt - (amt * 4 / 100);  
        Payment others = (amt) -> amt - (amt * 2 / 100);       

        System.out.println("UPI Payment: " + upi.cashBill(amount));
        System.out.println("Cash Payment: " + cash.cashBill(amount));
        System.out.println("Credit Card Payment: " + creditCard.cashBill(amount));
        System.out.println("Other Payment: " + others.cashBill(amount));
        
        System.out.println("Diwali Discount for All: " + upi.diwaliDiscount(amount));
    }
}
