/**
 * 
 */
/**
 * @author kavis
 *
 */
module functionalinterface {
}